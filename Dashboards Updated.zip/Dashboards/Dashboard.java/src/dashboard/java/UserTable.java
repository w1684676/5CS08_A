/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dashboard.java;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author 
 */
public class UserTable {
    
    public static void insert(String name, String email, String password)
    {
        Connection connection = DB.getConnection();
        
        String sql = "INSERT INTO User (Name, Email, Password) VALUES"
                +"("
                    +"'" + name + "',"
                    +"'" + email + "',"
                    +"'" + password + "'"
                + ")";
        try
        {
            Statement statement = connection.createStatement();
            statement.executeUpdate(sql);
            System.out.println("Person: " + name + "inserted");
            connection.close();
        }
        
        catch(Exception e)
        {
            System.out.println("Error while inserting." + e.getMessage());
        }           
    } 
    
    public static ResultSet get(String email)
    {
        Connection connection = DB.getConnection();
        
        String sql = "SELECT * FROM User WHERE Email = '"+ email + "'";
        ResultSet result = null;
        
        try
        {
            Statement statement = connection.createStatement();
            result = statement.executeQuery(sql);
            connection.close();
        }
        catch(Exception e)
        {
            System.out.println("Error");
        }
        finally
        {
            return result;
        }
                
        
    }
    
    
}
