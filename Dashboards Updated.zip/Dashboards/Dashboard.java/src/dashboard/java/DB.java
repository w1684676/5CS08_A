/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dashboard.java;

import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.Connection;
/**
 *
 * @author Ibrahim Ahmed
 */
public class DB {
   public static Connection getConnection()
   {
       String urlSQLite = "jdbc:sqlite:Login.db";
       
       try
       {
           Driver driverSQLite = new org.sqlite.JDBC();
           DriverManager.registerDriver(driverSQLite);
           System.out.println("SQL Driver loaded up");
       }
       catch(Exception e)
       {
           System.out.println("Theres a problem with the SQLite drivers" + e.getMessage());
           
       }
       
       Connection connection = null;
       
       try
       {
           connection = DriverManager.getConnection(urlSQLite);
           System.out.println("Connected to the database!");

       }
       catch(Exception e)
       {
           System.out.println("Error connecting to database!"+ e.getMessage());
       }
       return connection;
       
   }
}
