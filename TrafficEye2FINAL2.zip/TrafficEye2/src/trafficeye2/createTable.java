/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trafficeye2;

import java.sql.Connection;
import java.sql.Statement;

/**
 *
 * @author sayef
 */
public class createTable {
    public static void trafficTable()
    {
        Connection connection = Database.getConnection(); //need the connection object to execute a query
        //Query to execute, will create a table
        
        String sql = "CREATE TABLE if not exists TrafficDB"
                + "("
                + "count_point_id INTEGER,"
                + "    direction_of_travel STRING,"
                + "    year STRING,"
                + "    count_date STRING,"
                + "    hour INTEGER,"
                + "    region_name STRING,"
                + "    local_authority_id INTEGER,"
                + "    local_authority_name STRING,"
                + "    road_name STRING,"
                + "    road_type STRING,"
                + "    start_junction_road_name STRING,"
                + "    end_junction_road_name STRING,"
                + "    link_length_miles DOUBLE,"
                + "    pedal_cycles INTEGER,"
                + "    two_wheeled_motor_vehicles INTEGER,"
                + "    cars_and_taxis INTEGER,"
                + "    buses_and_coaches INTEGER,"
                + "    lgvs INTEGER,"
                + "    hgvs_2_rigid_axle INTEGER,"
                + "    hgvs_3_rigid_axle INTEGER,"
                + "    hgvs_4_or_more_rigid_axle INTEGER,"
                + "    hgvs_3_or_4_articulated_axle INTEGER,"
                + "    hgvs_5_articulated_axle INTEGER,"
                + "    hgvs_6_articulated_axle INTEGER,"
                + "    all_hgvs INTEGER,"
                + "    all_motor_vehicles INTEGER"
                + ");";
        
         try
        {
        Statement sqlStatement = connection.createStatement();
        sqlStatement.executeUpdate(sql);
        System.out.println("Table has been created successfully");
        }
        catch(Exception e)
        {
            System.out.println("There was an error creating the table..." + e.getMessage());
        }
    
    }
    
}
