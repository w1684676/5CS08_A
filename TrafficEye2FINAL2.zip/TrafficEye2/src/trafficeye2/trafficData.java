/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trafficeye2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author sayef
 */
public class trafficData {

    private static Connection connection = Database.getConnection();

    public static void insert(int count_point_id, String direction_of_travel, String year, String count_date, int hour, String region_name, int local_authority_id, String local_authority_name, String road_name, String road_type, String start_junction_road_name, String end_junction_road_name, double link_length_miles, int pedal_cycles, int two_wheeled_motor_vehicle, int cars_and_taxis, int buses_and_coaches, int lgvs, int hgvs_2_rigid_axle, int hgvs_3_rigid_axle, int hgvs_4_or_more_rigid_axle, int hgvs_3_or_4_articulated_axle, int hgvs_5_articulated_axle, int hgvs_6_articulated_axle, int all_hgvs, int all_motor_vehicles) {//here we can implement crud codes to insert data into our tables
        String sql = "INSERT INTO TrafficDB (count_point_id, direction_of_travel, year, count_date, hour, region_name, local_authority_id, local_authority_name, road_name, road_type, start_junction_road_name, end_junction_road_name, link_length_miles, pedal_cycles, two_wheeled_motor_vehicles, cars_and_taxis, buses_and_coaches, lgvs, hgvs_2_rigid_axle, hgvs_3_rigid_axle, hgvs_4_or_more_rigid_axle, hgvs_3_or_4_articulated_axle, hgvs_5_articulated_axle, hgvs_6_articulated_axle, all_hgvs, all_motor_vehicles) VALUES"
                + "("
                + "'" + count_point_id + "',"
                + "'" + direction_of_travel + "',"
                + "'" + year + "',"
                + "'" + count_date + "',"
                + "'" + hour + "',"
        //        + ");"
        //        + "INSERT INTO Area (region_name, local_authority_id, local_authority_name, road_name, road_type, start_junction_road_name, end_junction_road_name, link_length_miles) VALUES"
       //         + "("
                + "'" + region_name + "',"
                + "'" + local_authority_id + "',"
                + "'" + local_authority_name + "',"
                + "'" + road_name + "',"
                + "'" + road_type + "',"
                + "'" + start_junction_road_name + "',"
                + "'" + end_junction_road_name + "',"
                + "'" + link_length_miles + "',"
       //         + ");"
      //          + "INSERT INTO Vehicles (pedal_cycles, two_wheeled_motor_vehicles, cars_and_taxis, buses_and_coaches, lgvs, hgvs_2_rigid_axle, hgvs_3_rigid_axle, hgvs_4_or_more_rigid_axle, hgvs_3_or_4_articulated_axle, hgvs_5_articulated_axle, hgvs_6_articulated_axle, all_hgvs, all_motor_vehicles) VALUES"
     //           + "("
                + "'" + pedal_cycles + "',"
                + "'" + two_wheeled_motor_vehicle + "',"
                + "'" + cars_and_taxis + "',"
                + "'" + buses_and_coaches + "',"
                + "'" + lgvs + "',"
                + "'" + hgvs_2_rigid_axle + "',"
                + "'" + hgvs_3_rigid_axle + "',"
                + "'" + hgvs_4_or_more_rigid_axle + "',"
                + "'" + hgvs_3_or_4_articulated_axle + "',"
                + "'" + hgvs_5_articulated_axle + "',"
                + "'" + hgvs_6_articulated_axle + "',"
                + "'" + all_hgvs + "',"
                + "'" + all_motor_vehicles + "'"
                + ");";

        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(sql);
            System.out.println("Data has been successfully inserted into the Traffic Table!");
        } catch (Exception e) {
            System.out.println("Error while inserting into the Traffic Table " + e.getMessage());
        }
    }
    
    public static void batchInsert(ArrayList<String> input) {
        for (String currentLine : input) {
            String[] lineArray = currentLine.split(",");
            int count_point_id = Integer.parseInt(lineArray[0]);
            String direction_of_travel = lineArray[1];
            String year = lineArray[2];
            String count_date = lineArray[3];
            int hour = Integer.parseInt(lineArray[4]);
            String region_name = lineArray[5];
            int local_authority = Integer.parseInt(lineArray[6]);
            String local_authority_name = lineArray[7];
            String road_name = lineArray[8];
            String road_type = lineArray[9];
            String start_junction_road_name = lineArray[10];
            String end_junction_road_name = lineArray[11];
            double link_length_miles = Double.parseDouble(lineArray[12]);
            int pedal_cycles = Integer.parseInt(lineArray[13]);
            int two_wheeled_motor_vehicles = Integer.parseInt(lineArray[14]);
            int cars_and_taxis = Integer.parseInt(lineArray[15]);
            int buses_and_coaches = Integer.parseInt(lineArray[16]);
            int lgvs = Integer.parseInt(lineArray[17]);
            int hgvs_2_rigid_axle = Integer.parseInt(lineArray[18]);
            int hgvs_3_rigid_axle = Integer.parseInt(lineArray[19]);
            int hgvs_4_or_more_rigid_axle = Integer.parseInt(lineArray[20]);
            int hgvs_3_or_4_articulated_axle = Integer.parseInt(lineArray[21]);
            int hgvs_5_articulated_axle = Integer.parseInt(lineArray[22]);
            int hgvs_6_articulated_axle = Integer.parseInt(lineArray[23]);
            int all_hgvs = Integer.parseInt(lineArray[24]);
            int all_motor_vehicles = Integer.parseInt(lineArray[25]);

            insert(count_point_id, direction_of_travel, year, count_date, hour, region_name, local_authority, local_authority_name,
                    road_name, road_type, start_junction_road_name, end_junction_road_name, link_length_miles, pedal_cycles, two_wheeled_motor_vehicles,
                    cars_and_taxis, buses_and_coaches, lgvs, hgvs_2_rigid_axle, hgvs_3_rigid_axle, hgvs_4_or_more_rigid_axle, hgvs_3_or_4_articulated_axle,
                    hgvs_5_articulated_axle, hgvs_6_articulated_axle, all_hgvs, all_motor_vehicles);
        }

}
}