/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trafficeye2;

import java.util.ArrayList;

/**
 *
 * @author sayef
 */
public class TrafficEye2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Database.getConnection();
        //createTable.trafficTable();
        //trafficData.insert(1, "direction_of_travel", "year", "count_date", 0, "region_name", 0, "local_authority_name", "road_name", "road_type", "start_junction_road_name", "end_junction_road_name", "link_length_miles", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        ArrayList<String> fileContents = CSVReader.readFile("./dataSetUpdated.csv");
        trafficData.batchInsert(fileContents);
    }
    
}
